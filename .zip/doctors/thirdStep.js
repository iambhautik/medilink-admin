import React, { Fragment, useEffect, useState } from "react";
import { Tab, Tabs } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import SmallLoader from "../../../components/common/smallLoader";
import Toggle from "../../../components/common/toggle";
import Navbar from "../../../components/layout/Navbar";
import { GetDoctorProfile } from "../../../redux/actions/doctor/getDoctorDetails.action";
import { UpdateDoctorProfile } from "../../../redux/actions/doctor/registerDoctor.action";
import { isValidArray, sendNotification } from "../../../utils/utilities";

const ThirdStep = () => {
  let navigate = useNavigate();
  let dispatch = useDispatch();

  const getDoctorProfileReducer = useSelector(
    (state) => state.getDoctorProfileReducer
  );

  const [formData, setFormData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingUserData, setIsLoadingUserData] = useState(
    getDoctorProfileReducer.isLoading
  );

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    dispatch(GetDoctorProfile()).then(() => setIsLoadingUserData(false));
  }, [dispatch]);

  useEffect(() => {
    const { result } = getDoctorProfileReducer;
    if (isValidArray(result)) {
      setFormData(result);
    }
  }, [getDoctorProfileReducer]);

  const handleUserSubmit = (data) => {
    setIsLoading(true);
    console.log(data, "data");
    dispatch(UpdateDoctorProfile(data)).then(() => {
      setIsLoading(false);
      dispatch(GetDoctorProfile());
      sendNotification({ type: "success", message: "Profile Saved" });
    });
  };

  return (
    <Fragment>
      <Navbar />
      <div className="dr_wrapper">
        <div className="container-lg">
          <div className="row">
            <div className="col-md-12">
              <h2 className="user_heading mb-4">Start getting patients</h2>
            </div>
          </div>
            <>
              <div className="shadow p-3 p-lg-4 br-5">
                <form onSubmit={handleSubmit(handleUserSubmit)}>
                  {formData.map(
                    (
                      {
                        mobile = "",
                        email = "",
                        street_address = "",
                        landmark = "",
                        offline_first_time_fees = "",
                        offline_normal_fees = "",
                        offline_clinic_address = "",
                        offline_appointment_time,
                        online_first_time_fees = "",
                        online_normal_fees = "",
                        online_clinic_address = "",
                        online_appointment_time,
                        both_appointment_time,
                      },
                      i
                    ) => {
                      return (
                        <Fragment key={i}>
                          <div className="row mb-4">
                            <div className="col-md-12">
                              <h5 className="user_heading mb-4">
                                Map Location
                              </h5>
                            </div>
                            <div className="col-md-6">
                              <div className="mb-3">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="Phone number"
                                  name="mobile"
                                  readOnly
                                  {...register("mobile", {
                                    value: mobile,
                                  })}
                                />
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="mb-3">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="Email Addresses"
                                  name="email"
                                  readOnly
                                  {...register("email", {
                                    value: email,
                                  })}
                                />
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="mb-3">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="Street address"
                                  name="street_address"
                                  {...register("street_address", {
                                    required: "Street address is required",
                                    value: street_address,
                                  })}
                                />
                                {errors.street_address && (
                                  <p className="text-danger">
                                    {errors.street_address.message}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="mb-3">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="Landmark"
                                  name="landmark"
                                  {...register("landmark", {
                                    required: "Landmark is required",
                                    value: landmark,
                                  })}
                                />
                                {errors.landmark && (
                                  <p className="text-danger">
                                    {errors.landmark.message}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="row mb-4">
                              <div className="col-md-12">
                                <h5 className="user_heading mb-4">
                                  Establishment Timings
                                </h5>
                              </div>
                              <div className="col-md-6 col-lg-4"></div>
                            </div>

                            <div className="row mb-4">
                              <div className="col-md-12">
                                {/*  */}
                                <Tabs
                                  id="controlled-tab-example"
                                  // activeKey={key}
                                  // onSelect={(k) => setKey(k)}
                                  className="mb-3"
                                >
                                  {/* Offline */}
                                  <Tab eventKey="offline" title="Offline">
                                    <div className="row align-items-center">
                                      <div className="col-12 mt-3">
                                        <p>
                                          Appointment Fees (Offline - Clinic
                                          visit)
                                        </p>
                                      </div>
                                      <div className="col-md-4">
                                        <div className="mb-3">
                                          <input
                                            name="offline_first_time_fees"
                                            type="text"
                                            className="form-control"
                                            placeholder="First Time Fess"
                                            {...register(
                                              "offline_first_time_fees",
                                              {
                                                required: "Fees required",
                                                value: offline_first_time_fees,
                                              }
                                            )}
                                          />
                                          {errors.offline_first_time_fees && (
                                            <p className="text-danger">
                                              {
                                                errors.offline_first_time_fees
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                      <div className="col-md-4">
                                        <div className="mb-3">
                                          <input
                                            name="offline_normal_fees"
                                            type="text"
                                            className="form-control"
                                            placeholder="Normal Fess"
                                            {...register(
                                              "offline_normal_fees",
                                              {
                                                required: "Fees is required",
                                                value: offline_normal_fees,
                                              }
                                            )}
                                          />
                                          {errors.offline_normal_fees && (
                                            <p className="text-danger">
                                              {
                                                errors.offline_normal_fees
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                      <div className="col-md-4">
                                        <div className="mb-3">
                                          <input
                                            name="offline_clinic_address"
                                            type="text"
                                            className="form-control"
                                            placeholder="client Address"
                                            {...register(
                                              "offline_clinic_address",
                                              {
                                                required:
                                                  "Clinic address is required",
                                                value: offline_clinic_address,
                                              }
                                            )}
                                          />
                                          {errors.offline_clinic_address && (
                                            <p className="text-danger">
                                              {
                                                errors.offline_clinic_address
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                    <div className="row align-items-center">
                                      <div className="col-12 mt-3">
                                        <p>Add Timing</p>
                                      </div>
                                      <div className="col-md-4">
                                        <p>Days</p>
                                      </div>
                                      <div className="col-md-4">
                                        <p>Start Time</p>
                                      </div>
                                      <div className="col-md-4">
                                        <p>End Time</p>
                                      </div>
                                    </div>
                                    <Toggle
                                      errors={errors.offline_appointment_time}
                                      register={register}
                                      type="offline"
                                      setValue={setValue}
                                      formData={offline_appointment_time}
                                    />
                                  </Tab>

                                  {/* Online */}
                                  <Tab eventKey="online" title="Online">
                                    <div className="row align-items-center">
                                      <div className="col-12 mt-3">
                                        <p>
                                          Appointment Fees (Online - Clinic
                                          visit)
                                        </p>
                                      </div>
                                      <div className="col-md-4">
                                        <div className="mb-3">
                                          <input
                                            name="online_first_time_fees"
                                            type="text"
                                            className="form-control"
                                            placeholder="First Time Fess"
                                            {...register(
                                              "online_first_time_fees",
                                              {
                                                required: "Fees is required",
                                                value: online_first_time_fees,
                                              }
                                            )}
                                          />
                                          {errors.online_first_time_fees && (
                                            <p className="text-danger">
                                              {
                                                errors.online_first_time_fees
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                      <div className="col-md-4">
                                        <div className="mb-3">
                                          <input
                                            name="online_normal_fees"
                                            type="text"
                                            className="form-control"
                                            placeholder="Normal Fess"
                                            {...register("online_normal_fees", {
                                              required: "Fees is required",
                                              value: online_normal_fees,
                                            })}
                                          />
                                          {errors.online_normal_fees && (
                                            <p className="text-danger">
                                              {
                                                errors.online_normal_fees
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                      <div className="col-md-4">
                                        <div className="mb-3">
                                          <input
                                            name="online_clinic_address"
                                            type="text"
                                            className="form-control"
                                            placeholder="client Address"
                                            {...register(
                                              "online_clinic_address",
                                              {
                                                required:
                                                  "Clinic address is required",
                                                value: online_clinic_address,
                                              }
                                            )}
                                          />
                                          {errors.online_clinic_address && (
                                            <p className="text-danger">
                                              {
                                                errors.online_clinic_address
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                    <div className="row align-items-center">
                                      <div className="col-12 mt-3 mb-2">
                                        <p>Add Timing</p>
                                      </div>
                                      <div className="col-md-4">
                                        <p>Days</p>
                                      </div>
                                      <div className="col-md-4">
                                        <p>Start Time</p>
                                      </div>
                                      <div className="col-md-4">
                                        <p>End Time</p>
                                      </div>
                                    </div>
                                    <Toggle
                                      errors={errors.online_appointment_time}
                                      register={register}
                                      type="online"
                                      setValue={setValue}
                                      formData={online_appointment_time}
                                    />
                                  </Tab>

                                  {/* Both */}
                                  <Tab eventKey="both" title="Both">
                                    <div className="row align-items-center">
                                      <div className="col-12 mt-3">
                                        <p>
                                          Appointment Fees (Offline - Clinic
                                          visit)
                                        </p>
                                      </div>
                                      <div className="col-md-6">
                                        <div className="mb-3">
                                          <input
                                            type="text"
                                            className="form-control"
                                            placeholder="First Time Fess"
                                            name="both_offline_first_time_fees"
                                            {...register(
                                              "both_offline_first_time_fees",
                                              {
                                                required: "Fees required",
                                                value: offline_first_time_fees,
                                              }
                                            )}
                                          />
                                          {errors.both_offline_first_time_fees && (
                                            <p className="text-danger">
                                              {
                                                errors
                                                  .both_offline_first_time_fees
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                      <div className="col-md-6">
                                        <div className="mb-3">
                                          <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Normal Fess"
                                            name="both_offline_normal_fees"
                                            {...register(
                                              "both_offline_normal_fees",
                                              {
                                                required: "Fees is required",
                                                value: offline_normal_fees,
                                              }
                                            )}
                                          />
                                          {errors.both_offline_normal_fees && (
                                            <p className="text-danger">
                                              {
                                                errors.both_offline_normal_fees
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                    <div className="row align-items-center">
                                      <div className="col-12 mt-3">
                                        <p>
                                          Appointment Fees (Online - Clinic
                                          visit)
                                        </p>
                                      </div>
                                      <div className="col-md-4">
                                        <div className="mb-3">
                                          <input
                                            type="text"
                                            className="form-control"
                                            placeholder="First Time Fess"
                                            name="both_online_first_time_fees"
                                            {...register(
                                              "both_online_first_time_fees",
                                              {
                                                required: "Fees is required",
                                                value: online_first_time_fees,
                                              }
                                            )}
                                          />
                                          {errors.both_online_first_time_fees && (
                                            <p className="text-danger">
                                              {
                                                errors
                                                  .both_online_first_time_fees
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                      <div className="col-md-4">
                                        <div className="mb-3">
                                          <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Normal Fess"
                                            name="both_online_normal_fees"
                                            {...register(
                                              "both_online_normal_fees",
                                              {
                                                required: "Fees is required",
                                                value: online_normal_fees,
                                              }
                                            )}
                                          />
                                          {errors.both_online_normal_fees && (
                                            <p className="text-danger">
                                              {
                                                errors.both_online_normal_fees
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                      <div className="col-md-4">
                                        <div className="mb-3">
                                          <input
                                            type="text"
                                            name="both_online_clinic_address"
                                            className="form-control"
                                            placeholder="client Address"
                                            {...register(
                                              "both_online_clinic_address",
                                              {
                                                required:
                                                  "Clinic Address is required",
                                                value: online_clinic_address,
                                              }
                                            )}
                                          />
                                          {errors.both_online_clinic_address && (
                                            <p className="text-danger">
                                              {
                                                errors
                                                  .both_online_clinic_address
                                                  .message
                                              }
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                    <div className="row align-items-center">
                                      <div className="col-12 mt-3 mb-2">
                                        <p>Add Timing</p>
                                      </div>
                                      <div className="col-md-4">
                                        <p>Days</p>
                                      </div>
                                      <div className="col-md-4">
                                        <p>Start Time</p>
                                      </div>
                                      <div className="col-md-4">
                                        <p>End Time</p>
                                      </div>
                                    </div>
                                    <Toggle
                                      errors={errors.both_appointment_time}
                                      register={register}
                                      type="both"
                                      setValue={setValue}
                                      formData={both_appointment_time}
                                    />
                                  </Tab>
                                </Tabs>
                              </div>
                              <div className="col-md-6 col-lg-4"></div>
                            </div>

                            <div className="row">
                              <div className="col-12 text-center">
                                <button
                                  type="submit"
                                  className="btn btn-primary me-2 me-md-4"
                                >
                                  {isLoading ? <SmallLoader /> : "Save Profile"}
                                </button>
                                <button
                                  onClick={() => navigate("/second-step")}
                                  className="btn btn-primary"
                                >
                                  Go Back
                                </button>
                              </div>
                            </div>
                          </div>
                        </Fragment>
                      );
                    }
                  )}
                </form>
              </div>
            </>
        </div>
      </div>
    </Fragment>
  );
};

export default ThirdStep;
