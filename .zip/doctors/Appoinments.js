import React, { Fragment, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { CrossIcon, RightIcon } from "../../../components/common/Icons";
import { GetDoctorAppoinments } from "../../../redux/actions/doctor/appoinments.action";
import { isValidArray } from "../../../utils/utilities";

const Appoinments = () => {
  const dispatch = useDispatch();

  const [appoinments, setAppoinments] = useState([]);

  const appoinmentsReducer = useSelector((state) => state.appoinmentsReducer);

  useEffect(() => {
    dispatch(GetDoctorAppoinments());
  }, []);

  useEffect(() => {
    const { result } = appoinmentsReducer;
    if (isValidArray(result)) {
      setAppoinments(result);
    }
  }, [appoinmentsReducer]);

  return (
    <Fragment>
      {appoinments.map(({ que1, que2, que3, symptoms_days, symptoms, disease, speciality, doctor_id, patient_id, patient_name, patient_age,  }) => {

        return (
          <>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mt-3">
              <div class="card">
                <div class="card-body mx-4 my-5 p-0">
                  <h2 class="card-title text-center mb-2">Patient history</h2>
                  <div class="row">
                    <div class="col-xl-6 col-md-12 mt-2">
                      <div class=" border p-3">
                        <h4 class="mb-3">Patient Info</h4>
                        <p class="m-0">
                          <RightIcon />
                          {patient_name}
                        </p>
                        <p class="m-0">
                          <RightIcon />
                          {patient_age}
                        </p>
                        <p class="m-0">
                          <RightIcon />
                          mail
                        </p>
                      </div>
                    </div>
                    <div class="col-xl-6 col-md-12 mt-2">
                      <div class="border p-3">
                        <h4 class="mb-3">Patient problem</h4>
                        <p class="m-0">
                          <RightIcon />
                          {disease}
                        </p>
                        <p class="m-0">
                          <RightIcon />
                          {symptoms}
                        </p>
                        <p class="m-0">
                          <RightIcon />
                          {symptoms_days}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div class="mt-4 sec_para ">
                    <div class="d-flex align-items-center">
                      <p class="m-0">
                        <CrossIcon que={que1} />
                      </p>
                      <p class="m-0 ms-2">
                        Do you have any existing desis (like BP, sugar..)
                      </p>
                    </div>
                    <div class="d-flex align-items-center">
                      <p class="m-0">
                        <CrossIcon que={que2} />
                      </p>
                      <p class="m-0 ms-2">Are you allergic to any medication?</p>
                    </div>
                    <div class="d-flex align-items-center">
                      <p class="m-0">
                        <CrossIcon que={que3} />
                      </p>
                      <p class="m-0 ms-2">Are you allergic to any medication?</p>
                    </div>
                  </div>
                  <div class="sec_button text-center mt-5">
                    <button>
                      <Link
                        to={`/meet/${patient_id}/${doctor_id}`}
                       >
                        Connect To Patient
                      </Link>

                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        );
      })}

    </Fragment>
  );
};

export default Appoinments;
