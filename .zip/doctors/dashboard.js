import React, { Fragment } from "react";
import Navbar from "../../../components/layout/Navbar";
import Appoinments from "./Appoinments";

const DoctorDashboard = () => {
  return (
    <Fragment>
      <Navbar />
      <section class="section_wrapper bg_color">
        <div class="container-fluid">
          <div class="row">
            <Appoinments />
          </div>
        </div>
      </section>
    </Fragment>
  );
};

export default DoctorDashboard;
