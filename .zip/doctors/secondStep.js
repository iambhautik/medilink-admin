import React, { Fragment, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import SmallLoader from "../../../components/common/smallLoader";
import Navbar from "../../../components/layout/Navbar";
import { GetDoctorProfile } from "../../../redux/actions/doctor/getDoctorDetails.action";
import { UpdateDoctorProfile } from "../../../redux/actions/doctor/registerDoctor.action";
import { handleImageUpload, isValidArray, sendNotification } from "../../../utils/utilities";
import { Tabs } from 'antd';

const { TabPane} = Tabs

const SecondStep = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const getDoctorProfileReducer = useSelector(
    (state) => state.getDoctorProfileReducer
  );

  const [documents, setDocuments] = useState({
    establishment_proof: "",
    identity_proof: "",
    medical_proof: "",
  });

  const { establishment_proof, identity_proof, medical_proof } = documents;

  const [identityProof, setIdentityProof] = useState("");
  const [medicalProof, setMedicalProof] = useState("");
  const [establishmentProof, setEstablishmentProof] = useState("");

  useEffect(() => {
    dispatch(GetDoctorProfile());
  }, [dispatch]);

  useEffect(() => {
    const { result } = getDoctorProfileReducer;

    if (isValidArray(result)) {
      const [data] = result;

      const { establishment_proof, identity_proof, medical_proof } = data;

      setDocuments({
        establishment_proof: establishment_proof,
        identity_proof: identity_proof,
        medical_proof: medical_proof,
      });
    }
  }, [getDoctorProfileReducer]);

  const [isLoading, setIsLoading] = useState(false);

  const {
    register,
    formState: { errors },
    handleSubmit,
  } = useForm();

  const handleUserSubmit = (data) => {
    setIsLoading(true);
    let body = {
      identity_proof: identityProof || identity_proof,
      medical_proof: medicalProof || medical_proof,
      establishment_proof: establishmentProof || establishment_proof,
    };

    dispatch(UpdateDoctorProfile(body)).then((d) => {
      setIsLoading(false);
      navigate("/third-step");
    });
  };
  const handleImagesUpload = async (e) => {
    let size = e?.target?.files[0]?.size

    if(size < 250000){
      let name = e.target.name;
      let base64URL = await handleImageUpload(e, name);
      switch (name) {
        case "identity_proof":
          setIdentityProof(base64URL);
          break;
        case "medical_proof":
          setMedicalProof(base64URL);
          break;
        case "establishment_proof":
          setEstablishmentProof(base64URL);
          break;
        default:
          break;
      }
    } else {
      sendNotification({type: "error", message: "File size is too large. Maximum allowed size is 250KB"})
    }
  };

  return (
    <Fragment>
      <Navbar />
      <div className="dr_wrapper">
        <div className="container-lg">
          <div className="row">
            <div className="col-md-12">
              <h2 className="user_heading mb-4">Profile Verification</h2>
            </div>
          </div>
          <div className="shadow p-3 p-lg-4 br-5">
            <form onSubmit={handleSubmit(handleUserSubmit)}>
              <div className="row mb-4">
                <div className="col-md-12"></div>
                <div className="col-md-6 mb-3">
                  <h5 className="user_heading mb-2">Identity Proof</h5>
                  <div className="mb-3">
                    <input
                      className="form-control"
                      type="file"
                      id="identity_proof"
                      name="identity_proof"
                      onChange={handleImagesUpload}
                    />
                    <span className="fs-12">Note: Max. 250Kb</span>
                    {(identityProof || identity_proof) && (
                      <div className="documents">
                        <img src={identityProof || identity_proof} alt="identity proof"></img>
                      </div>
                    )}
                    {/* <span><a href={identity_proof} target="_blank" rel="noreferrer">{ identity_proof }</a></span> */}
                  </div>
                </div>
                <div className="col-md-6 mb-3">
                  <h5 className="user_heading mb-2">
                    Medical Registration Proof
                  </h5>
                  <div className="mb-3">
                    <input
                      className="form-control"
                      type="file"
                      id="medical_proof"
                      name="medical_proof"
                      onChange={handleImagesUpload}
                    />
                    <span className="fs-12">Note: Max. 250Kb</span>
                    {(medicalProof || medical_proof) && (
                      <div className="documents">
                        <img src={medicalProof || medical_proof} alt="identity proof"></img>
                      </div>
                    )}
                    {/* <span><a href={medical_proof} target="_blank" rel="noreferrer">{ medical_proof }</a></span> */}
                  </div>
                </div>
                <div className="col-md-6 mb-3">
                  <h5 className="user_heading mb-2">Establishment Proof</h5>
                  <div className="mb-3">
                    <input
                      className="form-control"
                      type="file"
                      id="establishment_proof"
                      name="establishment_proof"
                      onChange={handleImagesUpload}
                    />
                    <span className="fs-12">Note: Max. 250Kb</span>
                    {(establishmentProof || establishment_proof) && (
                      <div className="documents">
                        <img src={establishmentProof || establishment_proof} alt="identity proof"></img>
                      </div>
                    )}
                    {/* <span><a href={establishment_proof} target="_blank" rel="noreferrer">{ establishment_proof }</a></span> */}
                  </div>
                </div>
              </div>

              <div className="row">
                <div className="col-12 text-center">
                  <button type="submit" className="btn btn-primary me-2 me-md-4">
                    {isLoading ? <SmallLoader /> : "Next Step"}
                  </button>
                  <button onClick={() => navigate('/profile')} className="btn btn-primary">
                    Go Back
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default SecondStep;
