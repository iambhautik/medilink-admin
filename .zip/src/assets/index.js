// Import CSS
import 'antd/dist/antd.css';
import 'bootstrap/dist/css/bootstrap.css'
import 'react-toastify/dist/ReactToastify.css';
import './css/customForAntd.css'
import './css/mainLayout.css'
import './css/doctorDetails.css'

// Import JS
import 'bootstrap/dist/js/bootstrap.js'